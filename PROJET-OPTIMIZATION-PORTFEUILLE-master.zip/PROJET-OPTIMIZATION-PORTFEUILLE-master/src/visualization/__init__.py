# Visualization module initialization
